//: Playground - noun: a place where people can play

import UIKit

var userName : String?


userName?.uppercased()



var userAge = ""

userAge = "7"

if let userCalculations = Int(userAge) {
    let newNumber = userCalculations * 5
} else {
    print("you have to give me a number!")
}


