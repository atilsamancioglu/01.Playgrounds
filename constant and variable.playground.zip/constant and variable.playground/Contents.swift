//: Playground - noun: a place where people can play

import UIKit

//String
var str = "Hello, playground"

var name = "James"
var surname = "Hetfield"

var myString = "Apple"

myString.append("s")

myString.append(name)

myString = "Pear"

myString.lowercased()

var yourString : String


//Integer
let firstNumber = 3

let myDouble : Double

myDouble = 10.65

//Double or Float
let secondNumber = 3.5

Double(firstNumber) + secondNumber

//Boolean

var bool = true

bool = false


