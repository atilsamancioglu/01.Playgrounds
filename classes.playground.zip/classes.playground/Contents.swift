//: Playground - noun: a place where people can play

import UIKit

class People {
    
    var name = ""
    var age = 0
    var favoriteColor = ""
    var favoriteBand = ""
    var isADeveloper = true
    
}

var newUser = People()

newUser.name = "James"
newUser.age = 60
newUser.favoriteColor = "Black"
newUser.favoriteBand = "Metallica"
newUser.isADeveloper = false



