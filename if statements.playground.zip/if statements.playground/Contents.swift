//: Playground - noun: a place where people can play

import UIKit

// logical statements

// > : great than
// >= : greater or equal to
// < : less than
// <= : less than or equal to
// == : equal to
// != : not equal to
// && : and
// || : or


var myName = "James"

if myName == "James" {
    print("your surname is Hetfield")
} else if myName == "Lars" {
    print("your surname is Ulrich")
} else if myName == "Kirk" {
    print("you surname is Hammett")
} else if myName == "Rob" {
    print("your surname is Trojillo")
} else {
    print("you are not a member of Metallica")
}

var myNumber = 5

if myNumber <= 6 {
    print("my number is \(myNumber)")
}

