//: Playground - noun: a place where people can play

import UIKit

// while loop

var number = 10

while number > 1 {
    
    number = number - 2
    
}


// for loop

let animalArray = ["Snake", "Pig", "Cat", "Dog", "Mouse"]

var i = 1

for element in animalArray {
    i = i + 1
 
}

let pi = 3

for number in 1 ... pi {
    print(number)
}
