//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var animalArray = ["Lion", "Bird", "Giraffe", "Cat", "Dog", "Snake"]

animalArray.count

animalArray.append("Apple")

animalArray.remove(at: 6)

animalArray[0]

animalArray

animalArray.sort()

animalArray.removeAll()

animalArray.append("Lion King")


var myDictionary = ["pi" : 3.14, "n" : 5, "time" : 20, "velocity" : 50 ]

myDictionary["pi"] = 3

myDictionary["n"]

myDictionary.count

myDictionary.first

myDictionary["newNumber"] = 100

myDictionary


var dict : [String : Double]
